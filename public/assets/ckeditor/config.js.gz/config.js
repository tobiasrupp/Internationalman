/*
/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.editorConfig=function(a){a.toolbar=[{name:"document",items:["Print","Source"]},{name:"clipboard",items:["Undo","Redo"]},{name:"editing",items:["Find","Replace","-","SelectAll","-","SpellChecker","Scayt"]},{name:"basicstyles",items:["Bold","Italic","Underline","Strike","Subscript","Superscript","-","RemoveFormat"]},{name:"paragraph",items:["NumberedList","BulletedList","-","Outdent","Indent","-","JustifyLeft","JustifyCenter","JustifyRight","JustifyBlock"]},{name:"links",items:["Link","Unlink"]}],a.skin="office2003",a.autoGrow_onStartup=!0};